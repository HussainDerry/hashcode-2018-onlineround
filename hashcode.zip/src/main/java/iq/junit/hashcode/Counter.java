package iq.junit.hashcode;

public class Counter {

    public static int T = 0;

}
